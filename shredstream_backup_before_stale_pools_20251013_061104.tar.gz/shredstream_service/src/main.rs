use anyhow::Result;
use axum::{
    extract::State,
    response::Json,
    routing::get,
    Router,
};
use futures::StreamExt;
use serde::{Deserialize, Serialize};
use solana_entry::entry::Entry;
use solana_rpc_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::{commitment_config::CommitmentConfig, pubkey::Pubkey, transaction::Transaction};
use solana_stream_sdk::{CommitmentLevel, ShredstreamClient};
use std::collections::{HashMap, HashSet, VecDeque};
use std::str::FromStr;
use std::sync::Arc;
use tokio::sync::RwLock;
use tracing::{debug, error, info, warn};

mod dex_parser;

use dex_parser::{DexSwapParser, SwapInfo};

/// Individual swap record with timestamp
#[derive(Debug, Clone)]
struct SwapRecord {
    timestamp: chrono::DateTime<chrono::Utc>,
    volume_sol: f64,
}

/// Volume tracker with rolling 24-hour window
#[derive(Debug, Clone)]
struct VolumeTracker {
    swaps: VecDeque<SwapRecord>,
}

impl VolumeTracker {
    fn new() -> Self {
        Self {
            swaps: VecDeque::new(),
        }
    }

    /// Add a new swap and remove old ones outside 24h window
    fn add_swap(&mut self, volume_sol: f64) {
        let now = chrono::Utc::now();
        let cutoff = now - chrono::Duration::hours(24);

        // Remove swaps older than 24 hours
        while let Some(oldest) = self.swaps.front() {
            if oldest.timestamp < cutoff {
                self.swaps.pop_front();
            } else {
                break;
            }
        }

        // Add new swap
        self.swaps.push_back(SwapRecord {
            timestamp: now,
            volume_sol,
        });
    }

    /// Get total volume in last 24 hours
    fn get_24h_volume(&self) -> f64 {
        self.swaps.iter().map(|s| s.volume_sol).sum()
    }

    /// Get number of swaps in last 24 hours
    fn get_swap_count(&self) -> usize {
        self.swaps.len()
    }
}

/// Price information for a token on a specific DEX
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TokenPrice {
    pub token_mint: String,
    pub dex: String,
    pub price_sol: f64,
    pub last_update: chrono::DateTime<chrono::Utc>,
    pub volume_24h: f64,
    pub pool_address: String,  // CRITICAL FIX: Full 44-char address for DEX swaps
}

/// Internal price data with volume tracking
#[derive(Debug, Clone)]
struct PriceData {
    price: TokenPrice,
    volume_tracker: VolumeTracker,
    /// Full 44-character pool address (extracted from transaction accounts)
    full_pool_address: String,
}

/// Shared state for the service
#[derive(Clone)]
struct AppState {
    price_cache: Arc<RwLock<HashMap<String, PriceData>>>,
    rpc_client: Arc<RpcClient>,
    target_tokens: Arc<HashSet<String>>,  // BirdEye-vetted tokens (reduced filters)
}

/// REST API response for latest prices
#[derive(Debug, Serialize)]
struct LatestPricesResponse {
    prices: Vec<TokenPrice>,
    total_tokens: usize,
}

/// Target token from BirdEye filter
#[derive(Debug, Deserialize)]
struct TargetToken {
    address: String,
}

/// Target tokens file format
#[derive(Debug, Deserialize)]
struct TargetTokensFile {
    tokens: Vec<TargetToken>,
}

/// Whitelisted pool data from GeckoTerminal
#[derive(Debug, Clone, Deserialize)]
struct WhitelistedPool {
    pool_address: String,
    dex: String,
    liquidity_usd: f64,
    volume_24h_usd: f64,
    price_usd: f64,
}

/// Whitelisted pools file format (output from populate_whitelisted_pools.py)
#[derive(Debug, Deserialize)]
struct WhitelistedPoolsFile {
    pools: HashMap<String, Vec<WhitelistedPool>>,  // token_address -> pools
}

/// Load target tokens from BirdEye filter file
fn load_target_tokens() -> Result<HashSet<String>> {
    let file_path = "../target_tokens.json";

    match std::fs::read_to_string(file_path) {
        Ok(content) => {
            let target_file: TargetTokensFile = serde_json::from_str(&content)?;
            let tokens: HashSet<String> = target_file
                .tokens
                .into_iter()
                .map(|t| t.address)
                .collect();
            info!("✅ Loaded {} target tokens from {}", tokens.len(), file_path);
            Ok(tokens)
        }
        Err(_) => {
            warn!("⚠️ Target tokens file not found at {}, using empty whitelist", file_path);
            Ok(HashSet::new())
        }
    }
}

/// Validate that a pool exists on-chain and is not a ghost pool
/// Returns true if pool is valid, false if it's a ghost pool (0 bytes or too small)
async fn validate_pool_on_chain(
    rpc_client: &RpcClient,
    pool_address: &str,
    dex_name: &str,
) -> bool {
    // Parse pool address
    let pool_pubkey = match Pubkey::from_str(pool_address) {
        Ok(pk) => pk,
        Err(_) => {
            debug!("⚠️ Invalid pool address format: {}", pool_address);
            return false;
        }
    };

    // Fetch account data from chain
    match rpc_client.get_account_data(&pool_pubkey).await {
        Ok(data) => {
            // Check minimum size based on DEX type
            let min_size = match dex_name {
                name if name.starts_with("Orca_Whirlpools") => 234,  // Orca Whirlpool minimum
                name if name.starts_with("Raydium") => 200,           // Raydium pools
                name if name.starts_with("Meteora") => 150,           // Meteora pools
                _ => 100,                                              // Generic minimum
            };

            if data.len() < min_size {
                debug!(
                    "👻 Ghost pool detected: {} ({}) - Only {} bytes (expected ≥{})",
                    &pool_address[..8],
                    dex_name,
                    data.len(),
                    min_size
                );
                false
            } else {
                debug!(
                    "✅ Valid pool: {} ({}) - {} bytes",
                    &pool_address[..8],
                    dex_name,
                    data.len()
                );
                true
            }
        }
        Err(e) => {
            debug!(
                "⚠️ Pool validation failed for {}: {} - Treating as ghost pool",
                &pool_address[..8],
                e
            );
            false
        }
    }
}

#[tokio::main]
async fn main() -> Result<()> {
    // Initialize logging
    tracing_subscriber::fmt()
        .with_env_filter("info,shredstream_service=debug")
        .init();

    info!("🌊 Starting ShredStream Service");
    info!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

    // Load configuration
    dotenvy::dotenv().ok();
    let shreds_endpoint = std::env::var("SHREDS_ENDPOINT")
        .unwrap_or_else(|_| "https://shreds-ny6-1.erpc.global".to_string());
    let rpc_endpoint = std::env::var("SOLANA_RPC_ENDPOINT")
        .unwrap_or_else(|_| "https://edge.erpc.global".to_string());

    info!("📡 ShredStream endpoint: {}", shreds_endpoint);
    info!("🔗 RPC endpoint: {}", rpc_endpoint);

    // Initialize RPC client for ghost pool validation
    let rpc_client = Arc::new(RpcClient::new_with_commitment(
        rpc_endpoint,
        CommitmentConfig::confirmed(),
    ));
    info!("✅ RPC client initialized for pool validation");

    // Load BirdEye target tokens (reduced filters for pre-vetted tokens)
    let target_tokens = Arc::new(load_target_tokens()?);

    // Create shared state
    let app_state = AppState {
        price_cache: Arc::new(RwLock::new(HashMap::new())),
        rpc_client: rpc_client.clone(),
        target_tokens,
    };

    // Start ShredStream monitoring in background
    let monitor_state = app_state.clone();
    let monitor_endpoint = shreds_endpoint.clone();
    tokio::spawn(async move {
        if let Err(e) = run_shredstream_monitor(monitor_endpoint, monitor_state).await {
            error!("❌ ShredStream monitor failed: {}", e);
        }
    });

    // Build REST API
    let app = Router::new()
        .route("/health", get(health_check))
        .route("/prices", get(get_latest_prices))
        .route("/api/pool/:short_id", get(get_pool_address))
        .with_state(app_state);

    // Start API server
    let listener = tokio::net::TcpListener::bind("0.0.0.0:8080").await?;
    info!("🚀 REST API listening on http://0.0.0.0:8080");
    info!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

    axum::serve(listener, app).await?;

    Ok(())
}

/// Health check endpoint
async fn health_check() -> Json<serde_json::Value> {
    Json(serde_json::json!({
        "status": "healthy",
        "service": "shredstream_service",
        "version": "0.1.0"
    }))
}

/// Get latest prices endpoint
async fn get_latest_prices(
    State(state): State<AppState>,
) -> Json<LatestPricesResponse> {
    let cache = state.price_cache.read().await;

    // Filter prices for freshness (max 30 minutes old) and minimum volume
    let now = chrono::Utc::now();
    const MAX_AGE_MINUTES: i64 = 30;

    // Standard filters (strict - for unknown tokens)
    const MIN_VOLUME_24H_SOL: f64 = 5.0;    // 5 SOL minimum for 1 SOL capital
    const MIN_SWAP_COUNT_24H: usize = 5;    // 5 swaps minimum (filter one-trade wonders)

    // Relaxed filters (for BirdEye-vetted target tokens - already validated with 10k+ USD volume)
    const MIN_VOLUME_24H_SOL_WHITELIST: f64 = 1.0;   // 1 SOL for whitelisted
    const MIN_SWAP_COUNT_24H_WHITELIST: usize = 2;   // 2 swaps for whitelisted

    const MAX_PRICE_DEVIATION: f64 = 0.50;  // 50% max deviation from median (keep for all)

    // LAYER 3: Price Deviation Filter
    // Group prices by token to calculate median (detect outliers and dead pools)
    let mut token_prices: HashMap<String, Vec<f64>> = HashMap::new();
    for price_data in cache.values() {
        // Apply Layers 1 & 2 filters first
        let age = now.signed_duration_since(price_data.price.last_update);
        if age.num_minutes() >= MAX_AGE_MINUTES {
            continue;
        }

        // Check if token is whitelisted
        let is_whitelisted = state.target_tokens.contains(&price_data.price.token_mint);

        // Use relaxed filters for whitelisted tokens
        let volume_24h = price_data.volume_tracker.get_24h_volume();
        let min_volume = if is_whitelisted {
            MIN_VOLUME_24H_SOL_WHITELIST
        } else {
            MIN_VOLUME_24H_SOL
        };
        if volume_24h < min_volume {
            continue;
        }

        let swap_count = price_data.volume_tracker.get_swap_count();
        let min_swaps = if is_whitelisted {
            MIN_SWAP_COUNT_24H_WHITELIST
        } else {
            MIN_SWAP_COUNT_24H
        };
        if swap_count < min_swaps {
            continue;
        }

        // Collect prices for median calculation
        token_prices
            .entry(price_data.price.token_mint.clone())
            .or_insert_with(Vec::new)
            .push(price_data.price.price_sol);
    }

    // Calculate median price for each token
    let mut token_medians: HashMap<String, f64> = HashMap::new();
    for (token, mut prices) in token_prices {
        if prices.is_empty() {
            continue;
        }

        prices.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        let median = if prices.len() % 2 == 0 {
            (prices[prices.len() / 2 - 1] + prices[prices.len() / 2]) / 2.0
        } else {
            prices[prices.len() / 2]
        };
        token_medians.insert(token, median);
    }

    // Apply all 3 layers of filtering
    let prices: Vec<TokenPrice> = cache
        .values()
        .filter_map(|price_data| {
            // Layer 1: Freshness check
            let age = now.signed_duration_since(price_data.price.last_update);
            if age.num_minutes() >= MAX_AGE_MINUTES {
                return None;
            }

            // Check if token is whitelisted (BirdEye-vetted target)
            let is_whitelisted = state.target_tokens.contains(&price_data.price.token_mint);

            // Layer 2a: Volume check - filter out dead/fake pools
            // Use relaxed filter for whitelisted tokens (they're pre-validated)
            let volume_24h = price_data.volume_tracker.get_24h_volume();
            let min_volume = if is_whitelisted {
                MIN_VOLUME_24H_SOL_WHITELIST
            } else {
                MIN_VOLUME_24H_SOL
            };
            if volume_24h < min_volume {
                return None;
            }

            // Layer 2b: Swap count check - filter out illiquid pools
            // A pool with high volume but few swaps is likely a single large trade (unreliable price)
            // Relaxed for whitelisted tokens
            let swap_count = price_data.volume_tracker.get_swap_count();
            let min_swaps = if is_whitelisted {
                MIN_SWAP_COUNT_24H_WHITELIST
            } else {
                MIN_SWAP_COUNT_24H
            };
            if swap_count < min_swaps {
                return None;
            }

            // Layer 3: Price deviation check - filter out manipulated/dead pools
            // Reject price == 0.0 (dead pools like Czfq3xZZ on pool 7rhxnLV8)
            if price_data.price.price_sol == 0.0 {
                return None;
            }

            // Reject prices >50% deviation from median (outliers like AgeSxtVW: 815923% higher)
            if let Some(&median) = token_medians.get(&price_data.price.token_mint) {
                if median > 0.0 {
                    let deviation = (price_data.price.price_sol - median).abs() / median;
                    if deviation > MAX_PRICE_DEVIATION {
                        return None;
                    }
                }
            }

            // Return clean price with updated volume
            let mut price = price_data.price.clone();
            price.volume_24h = volume_24h;
            Some(price)
        })
        .collect();

    let total_tokens = prices.len();

    Json(LatestPricesResponse {
        prices,
        total_tokens,
    })
}

/// Get full pool address by short ID (8-char prefix)
async fn get_pool_address(
    State(state): State<AppState>,
    axum::extract::Path(short_id): axum::extract::Path<String>,
) -> Result<Json<serde_json::Value>, axum::http::StatusCode> {
    use axum::extract::Path;

    let cache = state.price_cache.read().await;

    // Search through all cached pools for matching short ID
    for (cache_key, price_data) in cache.iter() {
        // Extract pool ID from cache key (format: "token_dex_poolid")
        if let Some(pool_id_in_key) = cache_key.split('_').nth(2) {
            // Check if this pool matches the requested short ID
            if price_data.full_pool_address.starts_with(&short_id) {
                return Ok(Json(serde_json::json!({
                    "full_address": price_data.full_pool_address,
                    "pool_address": price_data.full_pool_address,
                    "short_id": short_id,
                    "token_mint": price_data.price.token_mint,
                    "dex": price_data.price.dex,
                    "last_seen": price_data.price.last_update,
                })));
            }
        }
    }

    // Not found
    Err(axum::http::StatusCode::NOT_FOUND)
}

/// Main ShredStream monitoring loop
async fn run_shredstream_monitor(endpoint: String, state: AppState) -> Result<()> {
    info!("🌊 Connecting to ShredStream: {}", endpoint);

    // Connect to ShredStream
    let mut client = ShredstreamClient::connect(&endpoint).await?;
    info!("✅ Connected to ShredStream successfully");

    // Create subscription request filtered by DEX program IDs
    // This filters out Jupiter aggregated swaps and shows ONLY direct DEX swaps
    let dex_programs = vec![
        // Raydium - Multiple Pool Types (4 variants)
        "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8".to_string(), // Raydium AMM V4
        "CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK".to_string(), // Raydium CLMM
        "CPMMoo8L3F4NbTegBCKVNunggL7H1ZpdTHKxQB5qKP1C".to_string(), // Raydium CPMM
        "5quBtoiQqxF9Jv6KYKctB59NT3gtJD2Y65kdnB1Uev3h".to_string(), // Raydium Stable

        // Orca - Multiple Pool Types (2 variants)
        "9W959DqEETiGZocYWCQPaJ6sBmUzgfxXfqGeTEdp3aQP".to_string(), // Orca Legacy
        "whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc".to_string(), // Orca Whirlpools

        // Jupiter EXCLUDED - it's an aggregator that already finds best prices
        // We want to compete with Jupiter by finding arbitrage across raw DEXs

        // Serum
        "9xQeWvG816bUx9EPjHmaT23yvVM2ZWbrrpZb9PusVFin".to_string(), // Serum DEX

        // Meteora - Multiple Pool Types (3 variants)
        "Eo7WjKq67rjJQSZxS6z3YkapzY3eMj6Xy8X5EQVn5UaB".to_string(), // Meteora DAMM V1
        "LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo".to_string(), // Meteora DLMM
        "cpamdpZCGKUy5JxQXB4dcpGPiikHawvSWAd6mEn1sGG".to_string(), // Meteora DAMM V2

        // PumpFun/PumpSwap
        "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA".to_string(), // PumpSwap

        // Additional DEXs
        "AMM55ShdkoGRB5jVYPjWziwk8m5MpwyDgsMWHaMSQWH6".to_string(), // Aldrin
        "SSwapUtytfBdBn1b9NUGG6foMVPtcWgpRU32HToDUZr".to_string(), // Saros (FIXED typo)
        "6MLxLqiXaaSUpkgMnWDTuejNZEz3kE7k2woyHGVFw319".to_string(), // Crema
        "CTMAxxk34HjKWxQ3QLZQA1EQdxtjbYGP4Qjrw7nTn8bM".to_string(), // Cropper
        "2wT8Yq49kHgDzXuPxZSaeLaH1qbmGXtEyPy64bL7aD3c".to_string(), // Lifinity V2 (CORRECTED)
        "FLUXubRmkEi2q6K3Y9kBPg9248ggaZVsoSFhtJHSrm1X".to_string(), // Fluxbeam (CORRECTED)
    ];

    info!("🎯 Filtering ShredStream for {} DEX programs", dex_programs.len());

    // Pre-filter ShredStream to DEX transactions by passing program IDs to owner_addresses
    // This is efficient and correct - matches working MEV_Bot implementation
    // Empty owner_addresses would subscribe to ALL transactions, overwhelming the parser
    let request = ShredstreamClient::create_entries_request_for_accounts(
        vec![],                              // accounts (empty = all)
        dex_programs,                        // owner addresses = DEX program IDs (pre-filter to DEX txns)
        vec![],                              // transaction account addresses (empty = all)
        Some(CommitmentLevel::Processed),    // commitment level
    );

    // Subscribe to entries stream
    let mut stream = client.subscribe_entries(request).await?;
    info!("📡 Subscribed to ShredStream entries");

    // Create DEX parser
    let dex_parser = DexSwapParser::new();

    let mut entries_processed = 0u64;
    let mut swaps_detected = 0u64;

    info!("🔄 Starting to process ShredStream data...");

    // Process incoming shred entries
    while let Some(slot_entry_result) = stream.next().await {
        match slot_entry_result {
            Ok(slot_entry) => {
                // DEBUG: Log that we received data
                let bytes_len = slot_entry.entries.len();
                debug!("📦 Received slot {} with {} bytes", slot_entry.slot, bytes_len);

                // Deserialize entries from binary data
                let entries: Vec<Entry> = match bincode::deserialize(&slot_entry.entries) {
                    Ok(entries) => entries,
                    Err(e) => {
                        warn!("⚠️ Failed to deserialize entries: {}", e);
                        continue;
                    }
                };

                entries_processed += entries.len() as u64;

                // DEBUG: Log progress
                if entries_processed % 100 == 0 {
                    info!("📊 Processed {} entries, {} swaps detected", entries_processed, swaps_detected);
                }

                // Extract transactions from entries
                for entry in entries {
                    for tx in entry.transactions {
                        // Parse DEX swaps from transaction
                        let signature = format!("slot_{}_idx", slot_entry.slot);
                        if let Some(swap) = dex_parser.parse_transaction(&tx, signature, slot_entry.slot) {
                            swaps_detected += 1;

                            // Update price cache with proper 24h rolling volume
                            // Cache key now includes pool_address to differentiate between pools
                            // This enables cross-pool arbitrage detection (e.g., Meteora DLMM vs Meteora Pools)
                            let pool_id = if swap.pool_address.len() >= 8 {
                                &swap.pool_address[..8]
                            } else {
                                &swap.pool_address
                            };
                            let cache_key = format!("{}_{}_{}", swap.token_mint, swap.dex_name, pool_id);
                            // FIXED: Use the SOL side of the trade for correct volume calculation
                            // This avoids decimal conversion issues (USDC uses 6 decimals, not 9)
                            let swap_volume_sol = if swap.is_buy {
                                // Buying token with SOL - amount_in is in SOL
                                swap.amount_in as f64 / 1e9
                            } else {
                                // Selling token for SOL - amount_out is in SOL
                                swap.amount_out as f64 / 1e9
                            };

                            // GHOST POOL VALIDATION: DISABLED AT CACHE TIME
                            // Pool addresses extracted from DEX instructions are unreliable
                            // (different DEXs use different account layouts - index 1 is not always the pool)
                            // Instead, we rely on 3-layer filtering (volume, swaps, price deviation)
                            // The bot will validate pools when executing trades (RPC getAccountInfo check)

                            let mut cache = state.price_cache.write().await;

                            // Get or create price data (only reached if pool is valid)
                            let price_data = cache.entry(cache_key.clone()).or_insert_with(|| {
                                PriceData {
                                    price: TokenPrice {
                                        token_mint: swap.token_mint.clone(),
                                        dex: format!("{}_{}", swap.dex_name, pool_id),  // Include pool ID in DEX name
                                        price_sol: 0.0,
                                        last_update: chrono::Utc::now(),
                                        volume_24h: 0.0,
                                        pool_address: swap.pool_address.clone(),  // CRITICAL FIX: Full 44-char address
                                    },
                                    volume_tracker: VolumeTracker::new(),
                                    full_pool_address: swap.pool_address.clone(),  // Store full 44-char address
                                }
                            });

                            // Add swap to volume tracker (automatically expires old swaps)
                            price_data.volume_tracker.add_swap(swap_volume_sol);

                            // Update price and timestamp
                            price_data.price.price_sol = swap.price_sol;
                            price_data.price.last_update = chrono::Utc::now();
                            price_data.price.volume_24h = price_data.volume_tracker.get_24h_volume();

                            if swaps_detected % 100 == 0 {
                                info!("📊 Stats: {} entries, {} swaps, {} cached prices",
                                    entries_processed, swaps_detected, cache.len());
                            }
                        }
                    }
                }
            }
            Err(e) => {
                error!("❌ ShredStream error: {}", e);
                // Continue processing despite errors
            }
        }
    }

    Ok(())
}
